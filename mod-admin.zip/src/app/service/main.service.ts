import { Injectable } from '@angular/core';
import { config } from './../shared/config';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';
import { disableDebugTools } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class MainService {

  constructor(private http: HttpClient) { }
  // public getAllMoments(per_page: number, page: number, post_status: any, post_id: number) {
  public getAllMoments(per_page: number, page: number, status: any) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.moments + "?per_page=" + per_page  + "&page=" + page  + '&post_status=' + status, { headers: headersObject });
    
    // const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    // const observe = 'response';
    // return this.http.get(config.apiUrl + config.moments + + '?post=' + postId + '&order=desc&per_page=' + count, { headers: headersObject, observe });

    // .subscribe((data: any) => {
    //   console.log(">>>>>>>>>>>>>>>>>>>" + data.length);
    // })

  }

  // Details moment
  public momentDetails(post_id: number) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.momentsDetails + "/" + post_id, { headers: headersObject });
  }
  // Details moment end

  public getAllMutedMoments(per_page: number, page: number, muted: boolean) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.moments + "?per_page=" + per_page + "&page=" + page + "&muted=true",  { headers: headersObject });
  }



  // return this.commonService.httpGet(this.baseURL + this.postCommentApi + '?post=' + postId + '&order=desc&per_page=' + count, headersObject, observe);

  /**
   * Get all media
   * @param per_page 
   */


  // https://api.tripify.co.in/backend/admin/media?per_page=25&post=0&page=1&violence=UNLIKELY&racy=VERY_LIKELY

  public getAllMedia(per_page: number, post_id: number, page: number, post_status: any, author: number,flagValueAdult:string = '', flagValueVoilence:string = '', flagValueSpoof:string = '', flagValueMedical:string = '', flagValueRacy:string = '') {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    // debugger
    // if (flagType !== "" && flagValue !== "") {
    //   var url = config.apiUrl + config.media + "?per_page=" + per_page + "&post=" + post_id + "&page=" + page + '&' + flagType + '=' + flagValue;
    //   return this.http.get<any>(config.apiUrl + config.media + "?per_page=" + per_page + "&post=" + post_id + "&page=" + page + "&author=" + author + '&' + flagType + '=' + flagValue, { headers: headersObject });
    // } else {
    //   return this.http.get<any>(config.apiUrl + config.media + "?per_page=" + per_page + "&post=" + post_id + "&page=" + page + "&author=" + author + { headers: headersObject });
    // }

    return this.http.get<any>(config.apiUrl + config.media + "?per_page=" + per_page + "&post=" + post_id + "&page=" + page + "&author=" + author + '&order=desc' + "&adult=" + flagValueAdult + "&voilence=" + flagValueVoilence+ "&spoof=" + flagValueSpoof + "&medical=" + flagValueMedical + "&racy=" + flagValueRacy, {headers: headersObject });

  }

  /* get all trips */
  public getAllTrips(per_page: number, author: number, page: number, post_status: any, post_id: number) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.trips + "?per_page=" + per_page + "&author=" + author + "&page=" + page + "&post_status=" + post_status + "&post=" + post_id, { headers: headersObject });
  }

   /* get interest id */
  public getInterestByID(interestID) {
    return this.http.get<any>(config.apiUrl + config.interest + "/" + interestID);
  }

  /* Report Moment Post */
  public reportMoment(feed: any, reason: any, feed_id: number) {
    const data = {
      "feed": feed,
      "reason": reason,
      "feed_id": feed_id
    };
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    return this.http.post<any>(config.apiUrl + config.reportMoment, data, { headers: headersObject })
  }
  /* unReport Moment Post */
  public unreportMoment(feed_id: number) {
    const data = {
      "feed_id": feed_id
    };
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    return this.http.post<any>(config.apiUrl + config.unreportMoment, data, { headers: headersObject })
  }
  /* Mute Moment Post */
  public muteMoment(feed: any, reason: any, moment_id: number ) {
    const data = {
      "feed": feed,
      "reason": reason,
      "moment_id": moment_id
   
    };
    debugger
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    return this.http.post<any>(config.apiUrl + config.muteMoment, data, { headers: headersObject })
  }
  /* unMute Moment Post */
  public unmuteMoment(feed: any, reason: any, moment_id: number, action: any ) {
    const data = {
      "feed": feed,
      "reason": reason,
      "moment_id": moment_id,
      "action": "unmute"
    };
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    return this.http.post<any>(config.apiUrl + config.muteMoment, data, { headers: headersObject })
  }

   /* All User Details */
    public userDetails(searchtxt:any, per_page: number, page: number) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.usersurl + "?search=" + searchtxt + "&per_page=" + per_page + "&page=" + page, { headers: headersObject });
  }
  

  /* All comments */
    public commentsAll( moment_id: number) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.comments + "?post=" + moment_id + '&order=desc' + '&per_page=99', { headers: headersObject });
  }
  /* Delete Comment */
  public commentDelete( comment_id: number, message:any) {
     const data = {
      "id": comment_id,
      "message": message
    };
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    return this.http.post<any>(config.apiUrl + config.deleteCommentApi, data, { headers: headersObject })
  }
  /* Post Comment */
  public postCommentApi( comment_id: number, content:any) {
    debugger
     const data = {
      
      content,
      post: comment_id
    };
    // const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const headersObject = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('UserToken'));
    return this.http.post<any>(config.apiUrl + config.comments, data, { headers: headersObject })
  }
  
  /**    * get destinaiton id   */
  public getDestinationId(name = "", city = "", state = "", country_code = "") {

    const data = {
      "name": name,
      "city": city,
      "state": state,
      "country_code": country_code,
    }
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    return this.http.post<any>(config.apiUrl + config.getV4DestinationId, data, { headers: headersObject });
  }

  
  /**    mark reviewed by   */
  public reviewedByMoment(moment_id: number) {
        const data = {
      "moment_id": moment_id,
    }
   
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    return this.http.post<any>(config.apiUrl + config.reviewdBy, data, { headers: headersObject });
  }

  /* All Search Website */
  public searchContent(searchField:any, searchFrom:any, per_page: number, page: number) {
    
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.search + "?" + searchFrom + "=" + searchField + "&per_page=" + per_page + "&page=" + page, { headers: headersObject });
  }

   /// helpfull and authentic and remove both

   public helpfullAndAuthentic(feed:any, moment_id:number, meta) {
    const data = {
      "feed": feed,
      "feed_id": moment_id,
      "meta": meta
    }
    const headersObject = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('UserToken'));
    return this.http.post<any>(config.apiUrl + config.likeAnswer, data, { headers: headersObject });
  }


  /* list of status */
  public remarkMoment(remarksmoment_id:any) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.remarkMoment , { headers: headersObject });
  }
  /* list of moderators */
  public listModerators() {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.listModerator , { headers: headersObject });
  }
  /* remarks in chronological order */
  public moderationsStatus(remarksmoment_id:any) {
    const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
    const observe = 'response';
    return this.http.get<any>(config.apiUrl + config.moderations + "?moment_id=" + remarksmoment_id , { headers: headersObject });
  }

  /// Save the additional status
  public setAdditionalStatus(moment_id:any, assigned_moderator_id:any, status:any, remarks:any) {
    
    const data = {
      "moment_id": moment_id,
      "assigned_moderator_id": assigned_moderator_id,
      "status": status,
      "remark": remarks,
    }
    const headersObject = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('UserToken'));
    return this.http.post<any>(config.apiUrl + config.saveRemarks, data, { headers: headersObject });
  }
  
}
