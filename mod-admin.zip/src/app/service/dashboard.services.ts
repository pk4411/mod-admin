import { Injectable} from '@angular/core';
import { config} from './../shared/config';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class DashboardService{

    constructor( private http: HttpClient){}

    public dashboardStaticData() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.dashboardStaticData, { headers: headersObject });
    }

    public dashboardActiveUsers() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.dashboardActiveUsers, { headers: headersObject });
    }
    public registrationsUsers() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.registrationsUsers, { headers: headersObject });
    }
    public weekAverages() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.weekAverages, { headers: headersObject });
    }
    public feedCounts() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.feedCounts, { headers: headersObject });
    }
    public averagePostPercentage() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.averagePostPercentage, { headers: headersObject });
    }
    public weeklyActiveUsers() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.weeklyActiveUsers, { headers: headersObject });
    }
    public postComponentsAll() {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.postComponents, { headers: headersObject });
    }
    public startEndData(startDate:any, endDate:any) {
        const headersObject = new HttpHeaders().set('Content-Type', 'application/json;');
        const observe = 'response';
        return this.http.get<any>(config.apiUrl + config.dateRange + "?start_date=" + startDate + "&end_date=" +  endDate, { headers: headersObject });
    }

}