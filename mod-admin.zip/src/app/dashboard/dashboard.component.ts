import { Component, OnInit, AfterViewInit } from '@angular/core';
import { TableData } from '../md/md-table/md-table.component';
import { LegendItem, ChartType } from '../md/md-chart/md-chart.component';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardService } from './../service/dashboard.services';
import { fromEvent, Observable } from "rxjs";
import { config } from './../shared/config';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';
import { disableDebugTools } from '@angular/platform-browser';
import * as Chartist from 'chartist';

declare const $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.scss']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  // constructor(private navbarTitleService: NavbarTitleService, private notificationService: NotificationService) { }

dashboarStaticdata:any;
dashboardUsers:any;
staticResults: string[];
usersResult: string[];
registerUsers: any[];
registration:any;
weekAverage:any;
weekAverageData:any;
feedCount:any;
feedCountData:any;
feedtoday :0;
feedlast7Days : 0;
feedlast30Days:0;
averagePostPer:any;
averagePostdata:any;
averageCount:any;

totalData:any;
totalImages:any;
totalVideos:any;
totalText:any;
totalTips:any;
start_date:any;
end_date:any;
dateapplybt = false;

analytics_goals:any

dateRangeData:any;
average_authentic_per_post:any;
average_comments_per_post:any;
average_helpful_per_post:any;
average_saves_per_post:any;
average_shares_per_post:any;
searchTerms:any;

showdateRangeData = false;

  constructor(public dashboardService: DashboardService, public router: Router, private http: HttpClient,
    public activatedRoute: ActivatedRoute
  ) { }

  public tableData: TableData;
 
  // constructor(private navbarTitleService: NavbarTitleService) { }
  public ngOnInit() {


// Static data of trips moment pitch comments

    this.dashboardStatics();
    this.dashboardActiveUsers();
    this.registrationsUsers();
    this.weekAverages();
    this.feedCounts(name);
    this.averagePost();
    this.postComponentData();

    this.start_date = document.getElementById("start_date");
    this.end_date = document.getElementById("end_date");
    // this.dateapplybt = document.getElementById("dateapplybt");


   }
   ngAfterViewInit() {

       /*  **************** Simple Bar Chart - barchart ******************** */
      

    
   }

// Dashboard Active Data
   dashboardStatics() {
    this.dashboardService.dashboardStaticData().subscribe(data => {
      this.staticResults = data;
      this.dashboarStaticdata = this.staticResults;
    })
  }  
// Dashboard Active Users
  dashboardActiveUsers() {
    this.dashboardService.dashboardActiveUsers().subscribe(data => {
      this.usersResult = data;
      this.dashboardUsers = this.usersResult;
      // console.log( this.dashboardUsers);
    })
  }  
  // Total Registration
  registrationsUsers() {
    this.dashboardService.registrationsUsers().subscribe(data => {
      this.registerUsers = data;
      this.registration = this.registerUsers;
      // console.log( this.dashboardUsers);
    })
  }  
  // Week Averages
  weekAverages() {
    this.dashboardService.weekAverages().subscribe(data => {
      this.weekAverage = data;
      this.weekAverageData = this.weekAverage;
      // console.log( this.weekAverage);
    })
  }  
  // feeds counts
  feedCounts(fname) {
    this.dashboardService.feedCounts().subscribe(data => {
      this.feedCount = data;
      this.feedCountData = this.feedCount;
      // console.log( this.feedCount);
      this.feedtoday  =  this.feedCountData.moments.today;
      this.feedlast7Days  =  this.feedCountData.moments.last7days;
      this.feedlast30Days =  this.feedCountData.moments.last30days;
        // debugger
            if(fname === "moments"){
              this.feedtoday  =  this.feedCountData.moments.today;
              this.feedlast7Days  =  this.feedCountData.moments.last7days;
              this.feedlast30Days =  this.feedCountData.moments.last30days;
            } else if(fname === "trips"){
              this.feedtoday  =  this.feedCountData.trips.today;
              this.feedlast7Days  =  this.feedCountData.trips.last7days;
              this.feedlast30Days =  this.feedCountData.trips.last30days;
            } else if(fname === "pitch"){
              this.feedtoday  =  this.feedCountData.pitch.today;
              this.feedlast7Days  =  this.feedCountData.pitch.last7days;
              this.feedlast30Days =  this.feedCountData.pitch.last30days;
            } else if(fname === "comments"){
              this.feedtoday  =  this.feedCountData.comments.today;
              this.feedlast7Days  =  this.feedCountData.comments.last7days;
              this.feedlast30Days =  this.feedCountData.comments.last30days;
            }
      
      const dataSimpleBarChart = {
       labels: ['Today : ' + this.feedtoday, 'Last 7 Days : ' + this.feedlast7Days, 'Last 30 Days : ' + this.feedlast30Days],
       series: [
         [this.feedtoday, this.feedlast7Days, this.feedlast30Days]
       ]
     };

     const optionsSimpleBarChart = {
       seriesBarDistance: 50,
       axisX: {
         showGrid: true
       }
     };

     const responsiveOptionsSimpleBarChart: any = [
       ['screen and (max-width: 640px)', {
         seriesBarDistance: 4,
         axisX: {
           labelInterpolationFnc: function (value: any) {
             return value[0];
           }
         }
       }]
     ];

     const simpleBarChart = new Chartist.Bar('#simpleBarChart', dataSimpleBarChart, optionsSimpleBarChart,
      responsiveOptionsSimpleBarChart);
      
    })
  }
  
    /*  **************** Average post weekly - Pie Chart ******************** */
      postComponentData(){

        this.dashboardService.postComponentsAll().subscribe(data => {

          let postcomponent:any = data;
          this.totalData = postcomponent;

          this.totalImages = postcomponent.images;
          this.totalVideos = postcomponent.videos;
          this.totalText = postcomponent.texts;
          this.totalTips = postcomponent.is_tip;

          const dataPreferences = {
            labels: [ this.totalImages, this.totalVideos, this.totalText, this.totalTips],
            series: [this.totalImages, this.totalVideos, this.totalText, this.totalTips]
        };

        const optionsPreferences = {
            height: '200px'
        };

        new Chartist.Pie('#postComponentData', dataPreferences, optionsPreferences);

      });
      }

   // Averages post by users
   averagePost() {
    this.dashboardService.averagePostPercentage().subscribe(data => {
      this.averagePostPer = data;
      this.averagePostdata = this.averagePostPer;
      // console.log( this.weekAverage);
    });
  } 

  selectdateRange(start:any, end:any){

     this.dashboardService.startEndData(this.start_date.value, this.end_date.value).subscribe(data =>  {
      this.showdateRangeData =  true;
      this.dateRangeData = data;
      this.analytics_goals = this.dateRangeData.analytics_goals;
      this.searchTerms = this.dateRangeData.top_search_terms;

      this.average_authentic_per_post = this.dateRangeData.average_authentic_per_post;
      this.average_comments_per_post = this.dateRangeData.average_comments_per_post;
      this.average_helpful_per_post = this.dateRangeData.average_helpful_per_post;
      this.average_saves_per_post = this.dateRangeData.average_saves_per_post;
      this.average_shares_per_post = this.dateRangeData.average_shares_per_post;

      })
  }


}
