import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MainService } from './../../service/main.service';
import { fromEvent, Observable } from "rxjs";
import { config } from '../../shared/config';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';

declare const $: any;
declare interface DataTable {
  headerRow: string[];
  footerRow: string[];
  dataRows: string[][];
}

@Component({
  selector: 'app-trips',
  templateUrl: './trips.component.html',
  styleUrls: ['./trips.component.css']
})
export class TripsComponent implements OnInit {
  trip_list: any;
  per_page: number;
  page: number;
  pageNumber:number;
  post_status:any;
  author: number;
  totalMomentsPublish=0;
  totalPage = 0;
  totalMomentsDraft=0;
  totalMomentsReport=0
  post_id=0;
  reportmoment_list: any;
  public dataTable: DataTable;
  feed_id: number;
  deletedTd: any;
  weburl='';
  reportStatus:any;
  momentId=0;
  constructor(public mainService: MainService, public router: Router,private http: HttpClient,
    public activatedRoute:ActivatedRoute 
    ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(data=>{
      // debugger
      this.momentId = data.id;

      if(this.momentId !==0 && this.momentId !==null && this.momentId !==undefined){
        this.post_id = this.momentId;  
        this.trips();
      }
    })


    // debugger
    this.pageNumber = 1;
    this.weburl=config.baseUrl;
    let nextBt = document.getElementsByClassName('mat-paginator-navigation-next');
    let prevBt = document.getElementsByClassName('mat-paginator-navigation-previous');

     const nextActionType =  fromEvent(nextBt,"click")
     nextActionType.subscribe(data=>{
      this.pageNumber = this.pageNumber + 1;
      // alert(this.pageNumber);
      this.setPage(this.pageNumber);
      })

      const prevActionType =  fromEvent(prevBt,"click")
      prevActionType.subscribe(data=>{
        this.pageNumber = this.pageNumber  - 1;
        this.setPage(this.pageNumber);
        // alert(this.pageNumber);
      })

    this.clearFilter();
    this.trips();

    this.dataTable = {
      headerRow: ['Author', 'Content', 'Media', 'Comment(s)', 'Authentic', 'Helpful', 'Date', 'Actions'],
      footerRow: ['Author', 'Content', 'Media', 'Comment(s)', 'Authentic', 'Helpful', 'Date', 'Actions'],

      dataRows: []
    };
  }

  trips() {
    this.mainService.getAllTrips(this.per_page, this.author, this.page, this.post_status, this.post_id).subscribe(data => {  
      // debugger
      let result:any = data;
      this.trip_list = data.trips;
       this.totalMomentsPublish = data["X-WP-publish"];
       this.totalMomentsDraft = data["X-WP-draft"];
       this.totalMomentsReport = data["X-WP-report"];
       this.totalPage =  this.totalMomentsPublish;
      
    })
  }
  
  interestByID(interestID) {
    this.mainService.getInterestByID(interestID).subscribe(data => {
    })
  }

  reportmomentvalue(list:any,event){
    this.deletedTd =  event.currentTarget.closest("tr");
    this.feed_id = list.ID;
     $("#reportModal").modal("show");
  }

  reportMoment(){
    this.mainService.reportMoment("feed","Reported by Admin", this.feed_id).subscribe(data => {
      this.reportmoment_list = data;
      this.deletedTd.remove();
    });
  }

  clearFilter() {
    this.per_page = 25;
    this.author = 0;
    this.page = 1;
    this.trips();
  }

  setAuthor(authorID) {
    this.author = authorID;
    this.trips();
  }

  setPage(page) {
    this.page = page;
    this.trips();
  }

  pageStatusClick(status,no){
    // debugger
    this.totalPage = no;
   if(status === "report"){
    this.totalMomentsReport = no;
    this.post_status = status;
    this.trips();
   }else if(status === "publish"){
    this.totalMomentsPublish = no;
    this.post_status = status;
    this.trips();
   } else if(status === "draft"){
    this.totalMomentsDraft = no;
    this.post_status = status;
    this.trips();
   }
  
  setTimeout(() => {
    this.totalPage = no;
  }, 1000);
 
  }
  redirectToMedia(list){
   debugger
    let id = list.ID;
    this.router.navigateByUrl("/triptalker/media/" + id);
   
  }

}
