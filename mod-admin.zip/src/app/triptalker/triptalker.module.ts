import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../app.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { FlexLayoutModule } from '@angular/flex-layout';

import { TriptalkerRoutes } from './triptalker.routing';
 
import { MomentslistComponent } from './momentslist/momentslist.component';
import { MomentdetailComponent } from './momentdetail/momentdetail.component';
import { MediaComponent } from './media/media.component';
import { TripsComponent } from './trips/trips.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { DestinationsComponent } from './destinations/destinations.component';
import { ScrollingModule} from '@angular/cdk/scrolling';
import { EmojiDirective } from '../directives/emoji.directive';
import { CarouselModule } from 'ngx-owl-carousel-o';

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(TriptalkerRoutes),
        FormsModule,
        MaterialModule,
        ReactiveFormsModule,
        ScrollingModule,
        CarouselModule
    ],
    declarations: [
        MomentslistComponent,
        MediaComponent,
        TripsComponent,
        UserdetailsComponent,
        DestinationsComponent,
        MomentdetailComponent,
        EmojiDirective
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class TriptalkerModule { }
