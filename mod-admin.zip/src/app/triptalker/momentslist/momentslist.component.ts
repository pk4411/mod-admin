import { Component, Directive, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MainService } from './../../service/main.service';
import { fromEvent, Observable } from "rxjs";
import { config } from '../../shared/config';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';
import { Location } from '@angular/common';


declare const $: any;
declare interface DataTable {
  headerRow: string[];
  footerRow: string[];
  dataRows: string[][];
}

@Component({
  selector: 'app-momentslist',
  templateUrl: './momentslist.component.html',
  styleUrls: ['./momentslist.component.scss'],
})
export class MomentslistComponent implements OnInit {

  

  moment_list: any;
  per_page: number;
  page: number;
  pageNumber: number;
  post_status: any;
  author: any;
  totalMomentsPublish = 0;
  totalPage = 0;
  totalMomentsDraft = 0;
  totalMomentsReport = 0
  moment_list_muted = 0;
  totalMomentsMuted = 0;
  post_id = 0;
  reportmoment_list: any;
  mutemoment_list: any;
  public dataTable: DataTable;
  feed_id: number;
  moment_id: number;
  deletedTd: any;
  muteTd: any;
  weburl = '';
  reportStatus: any;
  mutedrow: any;
  momentId = 0;
  muted: any;
  metaValue: number;

  isload : boolean;
  moment_details: any;
  deletecomment_list: any;
  comment_id: any;
  comments_all: any;
  selectComment: any;
  reasontxt: any;
  reviewedMoment: any;
  newComment: any;
  showCommentId:any;

  searchBtn: any;
  searchField: any;
  searchFrom: any;
  search_list: any;
  nodata = false;

  isDisableHelpful = false;
  isDisableAuthentic = false;
  
  helpFulCount: number = 0;
  authenticCount: number = 0;
  
  isHelpFull: boolean;
  isAuthentic: boolean;

  momentValue: number = 140;
  tipisValue: number = 100;

  momentTextLenght: number;
  momentTextMoreLess = " ...more";
  tipsTextLenght: number;
  tipsTextMoreLess = " ...more";

  // Additional status
  remarksStatus:any;
  remarksValue:any;
  remarksStatusValue:any;
  moderatorlistValue:any;

  remarksmoment_id:any;
  assigned_moderator_id:any;
  status:any;
  remarks:any;
  moderatorlist:any;
  moderatorRemarksList:any;

  @ViewChild("helpfull", { static: false }) helpfull: ElementRef;
  @ViewChild("authentic", { static: false }) authentic: ElementRef;

  constructor(public mainService: MainService, public router: Router, private http: HttpClient,
    public activatedRoute: ActivatedRoute, public location: Location
  ) {

    // this.moment();

  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(data => {
      // debugger
      this.post_status = "publish";
      this.momentId = data.id;
      if (this.momentId !== 0 && this.momentId !== null && this.momentId !== undefined) {
        this.post_id = this.momentId;
        this.moment();
      }
    });
    this.clearFilter();
    
    this.moment();

    this.searchBtn = document.getElementById("searchBtn");
    this.searchField = document.getElementById("searchField");
    this.searchFrom = document.getElementById("searchFrom");

    this.remarksValue = document.getElementById("additional-remarks");
    this.remarksStatusValue = document.getElementById("remarksStatus");
    this.moderatorlistValue = document.getElementById("moderatorlist");
    


    if (this.moment_list !== undefined && this.moment_list !== null) {
      this.helpFulCount = this.moment_list.helpful_count;
      this.authenticCount = this.moment_list.authentic_count;
      this.isHelpFull = this.moment_list.is_helpful_by_user;
      this.isAuthentic = this.moment_list.is_authentic_by_user;
    }

    this.momentTextLenght = this.momentValue;
    this.tipsTextLenght = this.tipisValue;

    // this.dataTable = {
    //   headerRow: ['Author', 'Content', 'Media', 'Comment(s)', 'Authentic', 'Helpful', 'Date', 'Reviewed by', 'Actions'],
    //   footerRow: ['Author', 'Content', 'Media', 'Comment(s)', 'Authentic', 'Helpful', 'Date', 'Reviewed by', 'Actions'],
    //   dataRows: []
    // };

   
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.

    // debugger
    this.pageNumber = 1;
    // this.weburl = config.baseUrl;
    
    // Selected tabs
    var btns = document.getElementsByClassName("menu");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function () {
        var current = document.getElementsByClassName("selected");
        current[0].className = current[0].className.replace(" selected", "");
        this.className += " selected";
      });
    }

    
    if (this.isHelpFull === true) {
      this.helpfull.nativeElement.classList.add("active");
    }
    if (this.isAuthentic === true) {
      this.authentic.nativeElement.classList.add("active");
    }
    setTimeout(() => {
      let nextBt:any = document.getElementsByClassName('mat-paginator-navigation-next');
      let prevBt:any = document.getElementsByClassName('mat-paginator-navigation-previous');
  
      const nextActionType = fromEvent(nextBt, "click")
      nextActionType.subscribe(data => {
        // alert("next page");
        this.pageNumber = this.pageNumber + 1;
        
        this.setPage(this.pageNumber);
      })
  
      const prevActionType = fromEvent(prevBt, "click")
      prevActionType.subscribe(data => {
        // alert("prev");
        this.pageNumber = this.pageNumber - 1;
        this.setPage(this.pageNumber);
        
      });

   

        }, 3000);
   
  }

  moment() {
    console.log("loader showing");
    // this.mainService.getAllMoments(this.per_page,  this.page, this.post_status, this.post_id).
    this.mainService.getAllMoments(this.per_page, this.page, this.post_status).subscribe(data => {
      // debugger
      // console.log("loader not showing");
      let result: any = data;
      this.moment_list = data.moments;
      this.totalMomentsPublish = data["X-WP-publish"];
      this.totalMomentsDraft = data["X-WP-draft"];
      this.totalMomentsReport = data["X-WP-report"];
      this.totalMomentsMuted = data["X-WP-muted"];
      this.totalPage = this.totalMomentsPublish;
      //  debugger
      if (this.post_status === "publish") {
        this.totalPage = this.totalMomentsPublish;
      }
      this.isload= true;
      // if(this.isload == true){
   
      // }
    })
  }

  momentDetails() {
    this.mainService.momentDetails(this.post_id).subscribe(data => {
      // debugger
      // let result: any = data;
      this.moment_details = data;

      if (this.moment_details.length == 0 && this.moment_details.length == undefined && this.moment_details.length == null) {
        this.router.navigateByUrl("/triptalker/moments");
      }
    })
  }
  momentMuted() {
    this.mainService.getAllMutedMoments(this.per_page, this.page, this.muted).subscribe(data => {
      // debugger
      let result: any = data;
      this.moment_details = data.moments;
      //  this.totalMomentsMuted = data["X-WP-muted"];
      this.totalPage = this.totalMomentsMuted;
    })
  }

  interestByID(interestID) {
    this.mainService.getInterestByID(interestID).subscribe(data => {
    })
  }

  // report Moment
  reportmomentvalue(moment_details: any, event) {
    // debugger
    // this.deletedTd = event.currentTarget.closest("tr");
    this.feed_id = moment_details.ID;
    $("#reportModal").modal("show");
  }

  reportMoment() {
    this.mainService.reportMoment("feed", "Reported by Admin", this.feed_id).subscribe(data => {
      this.reportmoment_list = data;
      // debugger
      // this.deletedTd.remove();
      // this.reportNotification(moment_details, event);
      this.moment();
    });
  }

  // unreport Moment
  unreportmomentvalue(moment_details: any, event) {
    // debugger
    // this.deletedTd = event.currentTarget.closest("tr");
    this.feed_id = moment_details.ID;
    $("#unreportModal").modal("show");
  }

  unreportMoment() {
    this.mainService.unreportMoment(this.feed_id).subscribe(data => {
      // this.feed_id = moment_details.ID;
      // $(this.muteTd).removeClass('disablerow');
      // this.muteTd({'pointer-events':'none', 'background-color':'grey'});
      this.moment();
    });
  }

  // mute Moment
  mutemomentvalue(list: any, event) {
    // this.muteTd = event.currentTarget.closest("tr");
    this.moment_id = list.ID;
    // debugger
    $("#muteModal").modal("show");
  }
  muteMoment() {
    this.mainService.muteMoment("feed", "Muted by Admin", this.moment_id).subscribe(data => {
      this.mutemoment_list = data;
      // debugger
      // $(this.muteTd).addClass('disablerow');
      // this.muteTd({'pointer-events':'none', 'background-color':'grey'});
      this.moment();
    });
  }
  // unmute Moment
  unmutemomentvalue(list: any, event) {
    // this.muteTd = event.currentTarget.closest("tr");
    this.moment_id = list.ID;
    $("#unmuteModal").modal("show");
  }
  unmuteMoment() {
    this.mainService.unmuteMoment("feed", "unMuted by Admin", this.moment_id, "action").subscribe(data => {
      this.mutemoment_list = data;
      $(this.muteTd).removeClass('disablerow');
      // this.muteTd({'pointer-events':'none', 'background-color':'grey'});
      this.moment()
    });
  }

  // All comments
  commentShow(showCommentAll) {

    this.mainService.commentsAll(showCommentAll).subscribe(data => {
      let result: any = data;
      this.comments_all = result;
      this.moment();

      $("#commentsallModal").modal("show");
      $("#allCommentSections").show();
      $("#deleteCommentsModal").hide();
    })

  }

  deleteConfirmPopup(comment_id: any) {
    this.selectComment = comment_id.id;
    $("#allCommentSections").hide();
    $("#deleteCommentsModal").show();
  }

  deleteComment() {

    const reasontxt: any = document.getElementById("commentReason");

    this.mainService.commentDelete(this.selectComment, reasontxt.value).subscribe(data => {
      // debugger
      console.log(this.selectComment + " " + reasontxt.value)
      this.deletecomment_list = data;
      // this.deletedTd = event.currentTarget.closest("table");
      // this.deletedTd.remove();
      // $("#commentsallModal").modal("hide");
      $("#commentsallModal").modal("hide");

    });
  }

  clearFilter() {
    this.per_page = 5;
    this.page = 1;
    this.searchField = document.getElementById("searchField");
    this.searchField.value = '';
    this.moment();
  }


  setAuthor(authorID) {
    this.author = authorID;
    this.moment();
  }

  setPage(page) {
    this.page = page;
    this.moment();
  }

  getRandom(id) {
    const abc = ["blueGredient", "greenGredient", "purpleGredient"];
    return abc[id % 3];
  }

  goBack() {
    this.location.back();
  }
  pageStatusClick(status:any, no:any) {
    // debugger
    this.totalPage = no;
    if (status === "report") {
      this.totalMomentsReport = no;
      this.post_status = status;
      this.moment();
    } else if (status === "publish") {
      this.totalMomentsPublish = no;
      this.post_status = status;
      this.moment();
    } else if (status === "draft") {
      this.totalMomentsDraft = no;
      this.post_status = status;
      this.moment();
    } else if (status === "muted") {
      this.totalMomentsMuted = no;
      this.post_status = status;
      this.moment();
    }

  setTimeout(() => {
      this.totalPage = no;
    }, 1000);
  }

  redirectToMedia(list) {
    //  debugger
    let id = list.ID;
    this.router.navigateByUrl("/triptalker/media/" + id);
  }

  gotoProfile(userid: any) {

    let profileUrl = (this.weburl + '/user-profile/' + userid);

    window.open(profileUrl, '_blank');
  }

  // Reviewed by set

  markReviewedBy(reviewed) {
    this.mainService.reviewedByMoment(reviewed).subscribe(data => {
      this.reviewedMoment = data;
    })
    this.moment();
  }


  // Destination click open in new url

  openDestination(city: any, state: any, countryCode: any) {
    let videos: any = document.getElementsByTagName('video')[0];
    if (videos !== undefined && videos !== null) {
      videos.pause();
    }


    this.mainService.getDestinationId('', city, state, countryCode).subscribe(data => {
      // debugger
      let result: any = data;
      // console.log(result.data.PCLI.name + " >>>>>>>>>>>>>");
      if (countryCode.toLowerCase() !== 'us' && countryCode.toLowerCase() !== '') {
        if (result.data.id !== "") {
          if (result.data.PCLI !== null && result.data.PCLI !== undefined && result.data.PCLI !== "") {

            this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.PCLI.name) + '/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
          } else if ((result.data.PCLI === null || result.data.PCLI === undefined) && (result.data.PCLI === undefined || result.data.PCLI === null)) {
            this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
          }
        }


      } else {
        if (result.data.ADM1 !== null && result.data.ADM1 !== undefined) {
          this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.ADM1.name) + '/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
        } else if ((result.data.ADM1 === null || result.data.ADM1 === undefined) && result.data.PCLI !== null && result.data.PCLI !== undefined) {
          this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.PCLI.name) + '/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
        } else if ((result.data.PCLI === null || result.data.PCLI !== undefined) && (result.data.ADM1 === null || result.data.ADM1 === undefined)) {
          this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
        }
      }
      const url = (this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
      window.open(url, '_blank');
    });
  }

  replaceDestinationURL(destinationName: string) {
    destinationName = destinationName.replace(/[,\s]+|[,\s]+/g, '-');
    destinationName = destinationName.replace('/', '-');
    destinationName = destinationName.replace('(', '');
    destinationName = destinationName.replace(')', '');
    destinationName = destinationName.toLowerCase();
    return destinationName;
  }

  urlify(text: string) {
    var urlRegex = /(\b(((https?|ftp|file|):\/\/)|www[.])[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    return text.replace(urlRegex, function (url, b, c) {
      var url2 = (c == 'www.') ? 'http://' + url : url;
      return '<a href="' + url2 + '" target="_blank">' + url + '</a>';
    });
  }


  // Post Comments
  commentSend(id: any, content: string) {
    this.mainService.postCommentApi(id, content).subscribe(data => {
      let result: any;
      this.newComment = '';
      result = data;
      // const data1: any = document.getElementById("commentMoment_" + id);
      if (result !== undefined && result !== null) {
        result.push(result);
        // id.preventDefault();
        
        setTimeout(() => {
            this.moment();
          }, 1000);

      }
    },
      err => {
        if (err.error.data.status === 400) {
          // this.toastService.toastError(err.error.message);
          alert('something wrong');
        }
        if (err.error.data.status === 409) {
          alert("Duplicate comment detected; it looks as though you've already said that!");
          // this.toastService.toastError("Duplicate comment detected; it looks as though you've already said that!");
        }
      });
  }



  // search form
  searchSite() {
    console.log(this.searchField.value + " >> " + this.searchFrom.value);
    // this.searchData();
    if (this.searchField.value.length !== 0) {
      // this.searchBt.disabled = true;
      this.nodata = false;
      this.searchData();
    } else {
      this.nodata = true;
      
      // this.searchBt.disabled = false;
    }

  }

  searchData() {
    this.isload= false;
    this.per_page = 99;
    this.mainService.searchContent(this.searchField.value, this.searchFrom.value, this.per_page, this.page).subscribe(data => {
      // console.log('inside conent');
      this.moment_list = data.moments;
      this.isload= true;
    })
  }

  // Helpful and Authentic
  
  helpfulFun(idMoment:any) {
    // debugger
      if (this.isDisableHelpful !== true) {
        this.isDisableHelpful = true;
        if (this.isHelpFull === false) {
          this.helpfull.nativeElement.classList.add("active");
          this.helpFulCount = this.helpFulCount + 1;
          this.mainService.helpfullAndAuthentic("moment", idMoment, "helpful").subscribe(data => {
            // debugger;
            this.isDisableHelpful = false;
            let result: any = data;
            this.isHelpFull = true;
            this.helpfull.nativeElement.classList.add("active");
            this.helpFulCount = result.data.count;
            // console.log(this.helpFulCount + " >>>>>>>>>>>>>>>>>>>>>>>>")
          }, err => {
            this.isDisableHelpful = false;
            this.helpFulCount = this.helpFulCount - 1;
            this.helpfull.nativeElement.classList.remove("active");
          });
        } else {
          this.helpfull.nativeElement.classList.remove("active");
          this.helpFulCount = this.helpFulCount - 1;
          this.mainService.helpfullAndAuthentic("moment", idMoment, "removehelpful").subscribe(data => {
            // debugger;
            this.isDisableHelpful = false
            let result: any = data;
            this.isHelpFull = false;
            this.helpfull.nativeElement.classList.remove("active");
            this.helpFulCount = result.data.count;
            // console.log(this.helpFulCount + " >>>>>>>>>>>>>>>>>>>>>>>> remove")

          }, error => {
            this.isDisableHelpful = false;
            this.helpFulCount = this.helpFulCount + 1;
            this.helpfull.nativeElement.classList.add("active");
          })
        }
      }
    this.moment();
  }

  authenticFun(idMoment:any) {
      if (this.isDisableAuthentic !== true) {
        this.isDisableAuthentic = true;
        if (this.isAuthentic === false) {
          this.authentic.nativeElement.classList.add("active");
          this.authenticCount = this.authenticCount + 1;
          this.mainService.helpfullAndAuthentic("moment", idMoment, "authentic").subscribe(data => {
            this.authentic.nativeElement.classList.add("active");
            this.isDisableAuthentic = false;
            let result: any = data;
            this.isAuthentic = true;
            this.authenticCount = result.data.count;
          }, err => {
            this.isDisableAuthentic = false;
            this.authenticCount = this.authenticCount - 1;
            this.authentic.nativeElement.classList.remove("active");
          });
        } else {
          this.authentic.nativeElement.classList.remove("active");
          this.authenticCount = this.authenticCount - 1;
          this.mainService.helpfullAndAuthentic("moment", idMoment, "removeauthentic").subscribe(data => {
            this.isDisableAuthentic = false
            let result: any = data;
            this.isAuthentic = false;
            this.authentic.nativeElement.classList.remove("active");
            this.authenticCount = result.data.count;
          }, error => {
            this.isDisableAuthentic = false;
            this.authenticCount = this.authenticCount + 1;
            this.authentic.nativeElement.classList.add("active");
          });
        }
      }
      this.moment();
  }

// more button in content
  momentTextFun() {
    if (this.momentTextLenght !== -1) {
      this.momentTextLenght = -1;
      this.momentTextMoreLess = " less";
    } else {
      this.momentTextLenght = this.momentValue;
      this.momentTextMoreLess = " ...more";
    }
  }

  
  tipsTextFun(event: Event) {
    if (this.tipsTextLenght !== -1) {
      this.tipsTextLenght = -1;
      this.tipsTextMoreLess = " less";
    } else {
      this.tipsTextLenght = this.tipisValue;
      this.tipsTextMoreLess = " ...more";
    }
  }

  
  // unmute Moment
  setRemarks(momentreMarksID: any) {
    this.remarksmoment_id = momentreMarksID.ID;
    console.log(">>>>>>>>>>>>>>>>>>>>>>" + momentreMarksID.ID);
    $("#remarksModal").modal("show");

    this.mainService.remarkMoment(this.remarksmoment_id).subscribe(data => {
      this.remarksStatus = data;
    });
    this.mainService.listModerators().subscribe(data => {
      this.moderatorlist = data;
    });
    this.mainService.moderationsStatus(this.remarksmoment_id).subscribe(data => {
      this.moderatorRemarksList = data;
      console.log(this.moderatorRemarksList + "**************")
    });

  }

  
  remarksMoment() {

    this.mainService.setAdditionalStatus(this.remarksmoment_id, this.moderatorlistValue.value, this.remarksStatusValue.value, this.remarksValue.value).subscribe(data => {
// debugger
// console.log(this.remarksmoment_id, this.moderatorlistValue.value, this.remarksStatusValue.value, this.remarksValue.value);

    });
    setTimeout(() => {
      this.moment();
    }, 1000);
  }
  title = 'angularowlslider';
  customOptions: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: false,
    pullDrag: false,
    dots: true,
    navSpeed: 700,
    center:true,
    autoHeight: true,
    navText : ['<i class="fa fa-angle-left" aria-hidden="true"></i>','<i class="fa fa-angle-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 1
      },
      740: {
        items: 1
      },
      940: {
        items: 1
      }
    },
    nav: true
  }

}