import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MainService } from './../../service/main.service';
import { fromEvent, Observable } from "rxjs";
import { config } from '../../shared/config';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';

declare const $: any;
declare interface DataTable {
  headerRow: string[];
  footerRow: string[];
  dataRows: string[][];
}

@Component({
  selector: 'app-destinations',
  templateUrl: './destinations.component.html',
  styleUrls: ['./destinations.component.css']
})
export class DestinationsComponent implements OnInit {

  numbers = [];
 
  constructor(public mainService: MainService, public router: Router, private http: HttpClient,
    public activatedRoute: ActivatedRoute
  ) { 

    for(let i =0; i < 1000; i++)
    this.numbers.push(i);

  }

  ngOnInit() {
   
  }



}
