import { Routes } from '@angular/router';

import { MomentslistComponent } from './momentslist/momentslist.component';
import { MomentdetailComponent } from './momentdetail/momentdetail.component';
import { MediaComponent } from './media/media.component';
import { TripsComponent } from './trips/trips.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { DestinationsComponent } from './destinations/destinations.component';


export const TriptalkerRoutes: Routes = [

    {
        path: '',
        children: [
            {
                path: 'moments',
                component: MomentslistComponent
            },
            {
               path: 'moments/:id',
                component: MomentdetailComponent
            },
            {
                path: 'media',
                component: MediaComponent
            },
            {
                path: 'media/:id',
                component: MediaComponent
            },
            {
                path: 'trips',
                component: TripsComponent
            },
            {
                path: 'trips/:id',
                 component: TripsComponent
             },
            {
                path: 'destinations',
                 component: DestinationsComponent
             },
             {
                 path: 'userdetails',
                 component: UserdetailsComponent
             }
        ]
    }
];
