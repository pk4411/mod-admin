import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MainService } from './../../service/main.service';
import { fromEvent, Observable } from "rxjs";
import { config } from '../../shared/config';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';

declare const $: any;
declare interface DataTable {
  headerRow: string[];
  footerRow: string[];
  dataRows: string[][];
}

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  users_list: any;
  per_page: 25;
  page: number;
  pageNumber: number;
  totalPage = 0;
  public dataTable: DataTable;
  weburl = '';
  momentId = 0;
  tripifyUsers: any;
  searchtxt: any;
  searchBt: any;
  nodata = false;
  constructor(public mainService: MainService, public router: Router, private http: HttpClient,
    public activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    // this.users();
    // debugger
    this.pageNumber = 1;
    this.weburl = config.baseUrl;
    let nextBt = document.getElementsByClassName('mat-paginator-navigation-next');
    let prevBt = document.getElementsByClassName('mat-paginator-navigation-previous');

    const nextActionType = fromEvent(nextBt, "click")
    nextActionType.subscribe(data => {
      this.pageNumber = this.pageNumber + 1;
      // alert(this.pageNumber);
      this.setPage(this.pageNumber);
    })

    const prevActionType = fromEvent(prevBt, "click")
    prevActionType.subscribe(data => {
      this.pageNumber = this.pageNumber - 1;
      this.setPage(this.pageNumber);
      // alert(this.pageNumber);
    })

    this.clearFilter();
    // this.users();
    this.dataTable = {
      headerRow: ['Avatar', 'Username', 'Email', 'Location'],
      footerRow: ['Avatar', 'Username', 'Email', 'Location'],
      dataRows: []
    };

    this.searchBt = document.getElementById("searchBt");
    this.searchtxt = document.getElementById("searchtxt");

  }


  searchUsers() {
    
    if (this.searchtxt.value.length !== 0) {
      // this.searchBt.disabled = true;
      this.nodata = false;
      this.users();
    } else {
      this.nodata = true;
      // this.searchBt.disabled = false;
    }

  }

  users() {
    this.mainService.userDetails(this.searchtxt.value, this.per_page, this.page).subscribe(data => {
      // debugger 
      this.users_list = data.users;
      if(this.users_list.length > 0){
        this.nodata = false;
      }else{
        // debugger
        this.nodata = true;
      }

      this.tripifyUsers = data["X-WP-publish"].avail_roles.tripify;
      this.totalPage = this.tripifyUsers;
    })
  }

  setAuthor(authorID) {
    // this.author = authorID;
    // this.trips();
  }

  clearFilter() {
    this.per_page = 25;
    this.page = 1;
    // this.users();
  }

  setPage(page) {
    this.page = page;
    // this.users();
  }



}
