import { Component, OnInit, AfterViewInit } from '@angular/core';
import { MainService } from './../../service/main.service';
import { renderFlagCheckIfStmt } from '@angular/compiler/src/render3/view/template';
import { Router, ActivatedRoute } from '@angular/router';
import { config } from '../../shared/config';
import { fromEvent, Observable } from "rxjs";

@Component({
  selector: 'app-media',
  templateUrl: './media.component.html',
  styleUrls: ['./media.component.css']
})
export class MediaComponent implements OnInit {
  mediacontent:any;
  headerRow : string[];
  mediaId= 0;
  post_id=0;
  totalMomentsPublish=0;
  totalPage = 0;
  totalMomentsDraft=0;
  totalMomentsReport=0
  post_status:any;
  per_page: number=25;
  page: number=1;
  author:any;
  pageNumber : number;
  weburl = '';
  
  
  constructor(public mainService: MainService,public route:Router, public activatedRoute:ActivatedRoute ) { }

  ngOnInit() {
    this.headerRow = ['Name', 'Media/Post Type', 'Media', 'View Post', 'Adult', 'Violence', 'Spoof', 'Racy', 'Medical'];
    this.activatedRoute.params.subscribe(data=>{
      this.mediaId = data.id;
      if(this.mediaId !==0 && this.mediaId !==null && this.mediaId !==undefined){
        this.post_id = this.mediaId;  
        this.media();
      }
    });

    // pagination
     this.pageNumber = 1;
     this.weburl=config.baseUrl;
     let nextBt = document.getElementsByClassName('mat-paginator-navigation-next');
     let prevBt = document.getElementsByClassName('mat-paginator-navigation-previous');
 
      const nextActionType =  fromEvent(nextBt,"click")
       nextActionType.subscribe(data=>{
       this.pageNumber = this.pageNumber + 1;
       // alert(this.pageNumber);
       this.setPage(this.pageNumber);
       })
 
       const prevActionType =  fromEvent(prevBt,"click")
       prevActionType.subscribe(data=>{
         this.pageNumber = this.pageNumber  - 1;
         this.setPage(this.pageNumber);
         // alert(this.pageNumber);
       })

    this.media();

    

  }

  media(){

    // const flagtype:any=document.getElementById("flagType");
    // const flagvalue:any=document.getElementById("flagValue");
    const flagValueAdult:any    =document.getElementById("flagValueAdult");
    const flagValueVoilence:any =document.getElementById("flagValueVoilence");
    const flagValueSpoof:any    =document.getElementById("flagValueSpoof");
    const flagValueRacy:any     =document.getElementById("flagValueRacy");
    const flagValueMedical:any  =document.getElementById("flagValueMedical");

    this.mainService.getAllMedia(this.per_page, this.post_id, this.page, this.author, this.post_status, flagValueAdult.value, flagValueVoilence.value, flagValueSpoof.value, flagValueRacy.value, flagValueMedical.value).subscribe(data => {
      // debugger
      this.mediacontent = data.media;
      this.totalMomentsPublish = data["X-WP-publish"];
      this.totalPage =  this.totalMomentsPublish;
      // console.log(this.totalPage + "**************")
    })
  }

  reportMedia(index){
    alert("this moment is reported");

  }
  
  setAuthor(authorID) {
    this.author = authorID;
    this.media();
  }

  setPage(page) {
    this.page = page;
    // console.log(this.page +  ">>>>>>>>>>>>>>>>>>>");
    this.media();
  }
  

  redirectToMoment(media){
    // debugger
    let id = media.post_parent_id;
    if(media.post_type ==="moments"){
      this.route.navigateByUrl("/triptalker/moments/" + id);
    }
    else if(media.post_type ==="trips"){
      this.route.navigateByUrl("/triptalker/trips/" + id);
    }


  }

}
