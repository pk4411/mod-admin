import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { MainService } from './../../service/main.service';
import { fromEvent, Observable } from "rxjs";
import { config } from '../../shared/config';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';
import { disableDebugTools } from '@angular/platform-browser';


declare const $: any;
declare interface DataTable {
  headerRow: string[];
  footerRow: string[];
  dataRows: string[][];
}

@Component({
  selector: 'app-momentdetail',
  templateUrl: './momentdetail.component.html',
  styleUrls: ['./momentdetail.component.scss'],
})
export class MomentdetailComponent implements OnInit {
  moment_details: any;
  per_page: number;
  page: number;
  pageNumber: number;
  post_status: any;
  author: number;
  totalMomentsPublish = 0;
  totalPage = 0;
  totalMomentsDraft = 0;
  totalMomentsReport = 0
  moment_list_muted = 0;
  totalMomentsMuted = 0;
  post_id = 0;
  reportmoment_list: any;
  deletecomment_list: any;
  comment_id:any;
  mutemoment_list: any;
  public dataTable: DataTable;
  feed_id: number;
  moment_id: number;
  deletedTd: any;
  muteTd: any;
  weburl = '';
  reportStatus: any;
  mutedrow: any;
  momentId = 0;
  muted: any;
  metaValue: number;
  comments_all:any;
  selectComment:any;
  reasontxt:any;
  reviewedMoment:any;
  newComment:any;


  constructor(public mainService: MainService, public router: Router, private http: HttpClient,
    public activatedRoute: ActivatedRoute, public location: Location
  ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(data => {
      // debugger
      
      this.momentId = data.id;
      if (this.momentId !== 0 && this.momentId !== null && this.momentId !== undefined) {
        this.post_id = this.momentId;
        
        this.momentDetails();
       
      }
    });
    this.clearFilter();
    
    this.momentDetails();

    // $("#deleteCommentsModal").modal("show");

    // $("#commentReason"). change(function(){
    //   this.reasontxt = $(this). children("option:selected"). val();
    //  console.log("You have selected the country - " + this.reasontxt);
    //  });

    this.weburl = config.baseUrl;
    
  }

  ngAfterViewInit() {
    
    setTimeout(() => {
      $('.carousel-item').removeClass('active');
      $(".carousel-inner .carousel-item:first-child").addClass('active');
    }, 3000);


  

  }
  
  momentDetails() {
    this.mainService.momentDetails(this.post_id).subscribe(data => {
      // debugger
      // let result: any = data;
      this.moment_details = data;

        if(this.moment_details.length == 0 && this.moment_details.length == undefined && this.moment_details.length == null ){
          this.router.navigateByUrl("/triptalker/moments");
        }
    })
  }
  momentMuted() {
    this.mainService.getAllMutedMoments(this.per_page, this.page, this.muted).subscribe(data => {
      // debugger
      let result: any = data;
      this.moment_details = data.moments;
      //  this.totalMomentsMuted = data["X-WP-muted"];
      this.totalPage = this.totalMomentsMuted;
    })
  }

  interestByID(interestID) {
    this.mainService.getInterestByID(interestID).subscribe(data => {
    })
  }

  // report Moment
  reportmomentvalue(moment_details: any, event) {
    // debugger
    // this.deletedTd = event.currentTarget.closest("tr");
    this.feed_id = moment_details.ID;
    $("#reportModal").modal("show");
  }

  reportMoment() {
    this.mainService.reportMoment("feed", "Reported by Admin", this.feed_id).subscribe(data => {
      this.reportmoment_list = data;
      // this.deletedTd.remove();
      // this.reportNotification(moment_details, event);
      this.momentDetails()
    });
  }

    // unreport Moment
    unreportmomentvalue(moment_details: any, event) {
      // debugger
      // this.deletedTd = event.currentTarget.closest("tr");
      this.feed_id = moment_details.ID;
      $("#unreportModal").modal("show");
    }
  
    unreportMoment() {
      this.mainService.unreportMoment(this.feed_id).subscribe(data => {
        // this.feed_id = moment_details.ID;
        // $(this.muteTd).removeClass('disablerow');
        // this.muteTd({'pointer-events':'none', 'background-color':'grey'});
        this.momentDetails()
      });
    }

  // mute Moment
  mutemomentvalue(list: any, event) {
    this.muteTd = event.currentTarget.closest("tr");
    this.moment_id = list.ID;
    $("#muteModal").modal("show");
  }
  muteMoment() {
    this.mainService.muteMoment("feed", "Muted by Admin", this.moment_id).subscribe(data => {
      this.mutemoment_list = data;
      $(this.muteTd).addClass('disablerow');
      // this.muteTd({'pointer-events':'none', 'background-color':'grey'});
      this.momentDetails()
    });
  }
  // unmute Moment
  unmutemomentvalue(list: any, event) {
    // this.muteTd = event.currentTarget.closest("tr");
    this.moment_id = list.ID;
    $("#unmuteModal").modal("show");
  }
  unmuteMoment() {
    this.mainService.unmuteMoment("feed", "unMuted by Admin", this.moment_id, "action").subscribe(data => {
      this.mutemoment_list = data;
      $(this.muteTd).removeClass('disablerow');
      // this.muteTd({'pointer-events':'none', 'background-color':'grey'});
      this.momentDetails()
    });
  }

  // All comments
  commentShow(post_id:number) {
    
    this.mainService.commentsAll(this.post_id).subscribe(data => {
      let result: any = data;
      this.comments_all = result;
  
      $("#commentsallModal").modal("show");
      $("#allCommentSections").show();
      $("#deleteCommentsModal").hide();
    })
    
  }

  deleteConfirmPopup(comment_id:any){
    this.selectComment = comment_id.id;
    $("#allCommentSections").hide();
    $("#deleteCommentsModal").show();
  }

  deleteComment() { 
   
    const reasontxt:any    = document.getElementById("commentReason");

    this.mainService.commentDelete(this.selectComment, reasontxt.value).subscribe(data => {
      // debugger
      console.log(this.selectComment + " " + reasontxt.value)
      this.deletecomment_list = data;
      // this.deletedTd = event.currentTarget.closest("table");
      // this.deletedTd.remove();
      // $("#commentsallModal").modal("hide");
      $("#commentsallModal").modal("hide");
      
    });
  }

  
 
  clearFilter() {

    this.page = 1;
    this.momentDetails();
  }
  setAuthor(authorID) {
    this.author = authorID;
    this.momentDetails();
  }

  setPage(page) {
    this.page = page;
    this.momentDetails();
  }

  getRandom(id) {
    const abc = ["blueGredient", "greenGredient", "purpleGredient"];
    return abc[id % 3];
  }

  goBack() {
    this.location.back();
  }
  // pageStatusClick(status, no) {
  //   // debugger
  //   this.totalPage = no;
  //   if (status === "report") {
  //     this.totalMomentsReport = no;
  //     this.post_status = status;
  //     this.moment();
  //   } else if (status === "publish") {
  //     this.totalMomentsPublish = no;
  //     this.post_status = status;
  //     this.moment();
  //   } else if (status === "draft") {
  //     this.totalMomentsDraft = no;
  //     this.post_status = status;
  //     this.moment();
  //   } else if (status === "muted") {
  //     this.totalMomentsMuted = no;
  //     this.post_status = status;
  //     this.moment();
  //   }

  // setTimeout(() => {
  //     this.totalPage = no;
  //   }, 1000);
  // }

  redirectToMedia(list) {
    //  debugger
    let id = list.ID;
    this.router.navigateByUrl("/triptalker/media/" + id);
  }


// Reviewed by set

markReviewedBy (reviewed){
  this.mainService.reviewedByMoment(reviewed).subscribe(data => {
    this.reviewedMoment = data;
  })
  this.momentDetails();
}


// Destination click open in new url

  openDestination(city: any, state: any, countryCode: any) {
    let videos: any = document.getElementsByTagName('video')[0];
    if (videos !== undefined && videos !== null) {
      videos.pause();
    }


    this.mainService.getDestinationId('', city, state, countryCode).subscribe(data => {
      // debugger
      let result: any = data;
      // console.log(result.data.PCLI.name + " >>>>>>>>>>>>>");
      if (countryCode.toLowerCase() !== 'us' && countryCode.toLowerCase() !== '') {
        if (result.data.id !== "") {
          if (result.data.PCLI !== null && result.data.PCLI !== undefined && result.data.PCLI !== "") {
            
            this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.PCLI.name) + '/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
          } else if ((result.data.PCLI === null || result.data.PCLI === undefined) && (result.data.PCLI === undefined || result.data.PCLI === null)) {
            this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
          }
        }
        
      
      } else {
        if (result.data.ADM1 !== null && result.data.ADM1 !== undefined) {
          this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.ADM1.name) + '/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
        } else if ((result.data.ADM1 === null || result.data.ADM1 === undefined) && result.data.PCLI !== null && result.data.PCLI !== undefined) {
          this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.PCLI.name) + '/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
        } else if ((result.data.PCLI === null || result.data.PCLI !== undefined) && (result.data.ADM1 === null || result.data.ADM1 === undefined)) {
          this.router.navigateByUrl(this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
        }
      }
      const url = (this.weburl + '/destinations/' + this.replaceDestinationURL(result.data.name) + '-' + result.data.id);
      window.open(url, '_blank');
    });
  }

  replaceDestinationURL(destinationName: string) {
    destinationName = destinationName.replace(/[,\s]+|[,\s]+/g, '-');
    destinationName = destinationName.replace('/', '-');
    destinationName = destinationName.replace('(', '');
    destinationName = destinationName.replace(')', '');
    destinationName = destinationName.toLowerCase();
    return destinationName;
  }

  urlify(text: string) {
    var urlRegex = /(\b(((https?|ftp|file|):\/\/)|www[.])[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    return text.replace(urlRegex, function (url, b, c) {
      var url2 = (c == 'www.') ? 'http://' + url : url;
      return '<a href="' + url2 + '" target="_blank">' + url + '</a>';
    });
  }


  // Post Comments
  commentSend(id: any, content: string) {
    this.mainService.postCommentApi(id, content).subscribe(data => {
      let result: any;
      this.newComment = '';
      result = data;
      // const data1: any = document.getElementById("commentMoment_" + id);
      if (result !== undefined && result !== null) {
        result.push(result);
        // id.preventDefault();

        
      }
    },
      err => {
        if (err.error.data.status === 400) {
          // this.toastService.toastError(err.error.message);
          alert('something wrong');
        }
        if (err.error.data.status === 409) {
          alert("Duplicate comment detected; it looks as though you've already said that!");
          // this.toastService.toastError("Duplicate comment detected; it looks as though you've already said that!");
        }
      });
  }

}
