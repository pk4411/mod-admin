import { EmojiDirective } from './emoji.directive';

describe('EmojiDirective', () => {
  it('should create an instance', () => {
    const directive = new EmojiDirective();
    expect(directive).toBeTruthy();
  });
});
