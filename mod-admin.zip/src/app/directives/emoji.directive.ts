import { Directive, ElementRef } from "@angular/core";

@Directive({
  selector: "[appEmoji]",
})
export class EmojiDirective {
  constructor(public el: ElementRef) {}

  ngOnInit() {}

  ngAfterViewInit() {
    let div = this.el.nativeElement.innerHTML;
    var regex = /(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])/g;
    let emoji: any = div.match(regex);
    let uniqueList = emoji.filter((item, i, ar) => ar.indexOf(item) === i);

    uniqueList.forEach((em) => {
      let rep = em;
      let re = new RegExp(rep, "g");
      div = div.replace(re, `<i class='emoji'> ${em} </i>`);
    });

    return (this.el.nativeElement.innerHTML = div);
  }
}
