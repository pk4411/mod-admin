export class User {
    email: String;
    password: String;
    url="test"
}