
export const config = {

  // dev
  
  //  moments: '/wp/v2/moments',
  login               : '/v2/users/login',
  dashboardStaticData : '/admin/total-counts',
  dashboardActiveUsers: '/admin/active-users',
  registrationsUsers  : '/admin/registrations',
  weekAverages        : '/admin/week-averages',
  feedCounts          : '/admin/feed-counts',
  averagePostPercentage: '/admin/analytics-percentages',
  weeklyActiveUsers   : '/admin/weekly-active-users-average-posts',
  postComponents      : '/admin/post-components',
  dateRange           : '/admin/analytics-date-range',


  moments             : '/admin/moments',
  momentsDetails      : '/admin/moment',
  interest            : '/wp/v2/interests',
  media               : '/admin/media',
  reportMoment        : '/v2/report',
  unreportMoment      : '/v2/unreport',

  muteMoment          : '/admin/mute-post',
  trips               : '/admin/trips',
  usersurl            : '/admin/users',
  comments            : '/wp/v2/comments',
  deleteCommentApi    : '/admin/delete-comment',

  getV4DestinationId  : '/v4/destination',

  reviewdBy           : '/admin/review',
  search              : '/admin/moments',
  likeAnswer          : '/v2/likes',

  remarkMoment        : '/admin/moderation-status',
  saveRemarks         : '/admin/moderation-status',
  listModerator       : '/admin/moderators',
  moderations         : '/admin/moderations',
}